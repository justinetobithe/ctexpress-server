<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('users')->insert([
            [
                'name' => 'Jazel Endriga',
                'email' => 'jazel.endriga@example.com',
                'password' => Hash::make('password'),
                'role' => 'Admin',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Cherrie Anne Paclibar',
                'email' => 'cherrie.paclibar@example.com',
                'password' => Hash::make('password'),
                'role' => 'Admin',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Steve Julian Villegas',
                'email' => 'steve.villegas@example.com',
                'password' => Hash::make('password'),
                'role' => 'Admin',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Driver One',
                'email' => 'driver.one@example.com',
                'password' => Hash::make('password'),
                'role' => 'Driver',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Driver Two',
                'email' => 'driver.two@example.com',
                'password' => Hash::make('password'),
                'role' => 'Driver',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Passenger One',
                'email' => 'passenger.one@example.com',
                'password' => Hash::make('password'),
                'role' => 'Passenger',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Passenger Two',
                'email' => 'passenger.two@example.com',
                'password' => Hash::make('password'),
                'role' => 'Passenger',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Passenger Three',
                'email' => 'passenger.three@example.com',
                'password' => Hash::make('password'),
                'role' => 'Passenger',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Passenger Four',
                'email' => 'passenger.four@example.com',
                'password' => Hash::make('password'),
                'role' => 'Passenger',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Passenger Five',
                'email' => 'passenger.five@example.com',
                'password' => Hash::make('password'),
                'role' => 'Passenger',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Passenger Six',
                'email' => 'passenger.six@example.com',
                'password' => Hash::make('password'),
                'role' => 'Passenger',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Passenger Seven',
                'email' => 'passenger.seven@example.com',
                'password' => Hash::make('password'),
                'role' => 'Passenger',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Passenger Eight',
                'email' => 'passenger.eight@example.com',
                'password' => Hash::make('password'),
                'role' => 'Passenger',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Passenger Nine',
                'email' => 'passenger.nine@example.com',
                'password' => Hash::make('password'),
                'role' => 'Passenger',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Passenger Ten',
                'email' => 'passenger.ten@example.com',
                'password' => Hash::make('password'),
                'role' => 'Passenger',
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}
